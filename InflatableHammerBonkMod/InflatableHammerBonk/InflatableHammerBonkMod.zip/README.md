# InflatableHammerBonk 
Changes the sound effect of hitting stuff with the inflatable hammer to a (perhaps louder) bonk sound effect.
<br />
