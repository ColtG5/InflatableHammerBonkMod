# Changelog
## 1.0.3
ACTUALLY fixed BepInEx dependancy version !
## 1.0.2
Removed some debug stuffs
## 1.0.1
Fixed BepInEx dependancy version
## 1.0.0
Initial release!